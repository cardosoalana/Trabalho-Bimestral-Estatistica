package com.curso.alana.ads.model

enum class Calculo {
    MEDIA_ARITIMÉTICA,
    MEDIANA,
    VARIANCIA_AMOSTRAL,
    DESVIO_PADRAO,
    COEFICIENTE_DE_VARIACAO,
    CONJUNTO_DE_DADOS
}