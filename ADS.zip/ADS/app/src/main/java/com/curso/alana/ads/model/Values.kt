package com.curso.alana.ads.model

data class Values(
    val ListaValores: List<Float>,
)
