package com.curso.alana.ads.view

import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.curso.alana.ads.R
import com.curso.alana.ads.databinding.ActivityMainBinding
import com.curso.alana.ads.model.Values
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var textValues: EditText
    private lateinit var listValues: List<Float>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setComponentsClick()
    }

    private fun setComponentsClick() {
        textValues = findViewById<EditText>(R.id.textValues)

        findViewById<MaterialButton>(R.id.buttonCalc).setOnClickListener {
            verifyNumbers()
        }

        findViewById<ImageView>(R.id.infoButton).setOnClickListener {
            showAlertDialog("Algumas recomendações:", "Para que a aplicação funcione corretamente, é necessário que você separe os números por ponto e vírgula (;) e não insira carcteres especiais nem letras.")
        }
    }

    private fun verifyNumbers() {
        if (!textValues.text.isNullOrEmpty()) {
            listValues = returnList()
            openBottomSheet()
        } else {
            showAlertDialog(getString(R.string.alert_dialog_ops),getString(R.string.alert_dialog_message_empty_calc))
        }
    }

    private fun returnList(): List<Float> {
        val list: List<Float> = textValues.text
            .replace("\\s".toRegex(), "")
            .replace( "#".toRegex(), "")
            .replace( "*", "")
            .replace( "N".toRegex(), "")
            .replace( "(", "")
            .replace( ")", "")
            .replace( "-".toRegex(), "")
            .replace( "+", "")
            .replace(",", ".")
            .replace("/", ".")
            .split(";")
            .filter { it.isNotBlank() }.map {
                it.toFloat()
            }

        return list
    }

    private fun showAlertDialog(title: String, message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setMessage(message)

        builder.setPositiveButton(android.R.string.yes) { dialog, which ->
            dialog.dismiss()
        }

        builder.show()
    }

    private fun openBottomSheet() {
        var bottomSheet = BottomSheet(Values(listValues))
        bottomSheet.show(supportFragmentManager, bottomSheet.tag)
    }
}