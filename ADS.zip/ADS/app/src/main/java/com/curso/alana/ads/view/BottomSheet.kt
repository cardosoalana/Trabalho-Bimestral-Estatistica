package com.curso.alana.ads.view

import android.app.Dialog
import android.content.ContentValues.TAG
import android.content.res.Resources
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.curso.alana.ads.R
import com.curso.alana.ads.R.id.*
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.curso.alana.ads.R.layout.modal_calc
import com.curso.alana.ads.model.Values
import kotlin.math.pow
import kotlin.math.sqrt


class BottomSheet(private val values: Values) : BottomSheetDialogFragment() {

    private lateinit var rootView: View
    lateinit var dialog: BottomSheetDialog
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<View>

    private lateinit var resultText: TextView
    private lateinit var MedianaText: TextView
    private lateinit var desvioText: TextView
    private lateinit var varianciaAmostralText: TextView
    private lateinit var desvioPadraoText: TextView
    private lateinit var coeficienteVariacaoText: TextView

    private var resultMedia: Double = 0.0
    private var desvioList = mutableListOf<Double>()
    private var desvioPowList = mutableListOf<Double>()
    var resultVarianciaAmostral: Double = 0.0
    var resultDesvioPadrao: Double = 0.0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bottomSheetBehavior = BottomSheetBehavior.from(view.parent as View)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        val layout = dialog.findViewById<CoordinatorLayout>(bottom)
        layout?.minimumHeight = (Resources.getSystem().displayMetrics.heightPixels)

        setUpComponents(view)
    }

    private fun setUpComponents(view: View) {
        resultText = view.findViewById<TextView>(R.id.resultText)
        MedianaText = view.findViewById<TextView>(R.id.resultMediana)
        desvioText = view.findViewById<TextView>(R.id.resultDesvio)
        varianciaAmostralText = view.findViewById<TextView>(R.id.resultVarianciaAmostral)
        desvioPadraoText = view.findViewById<TextView>(R.id.resultDesvioPadrao2)
        coeficienteVariacaoText = view.findViewById<TextView>(R.id.resultCoeficienteVariacao)

        showMediaAritimetica()
        showMediana()
        showVarianciaAmostral()
        showDesvioPadrao()
        showCoeficienteVariacao()
        closeDialog()
    }

    private fun showMediaAritimetica() {
        calcMediaAritimetica()
    }

    private fun calcMediaAritimetica() {
        resultMedia = values.ListaValores.sumOf { it.toDouble() / values.ListaValores.size }
        resultText.text = "Média Aritimética $resultMedia"

        calcDesvio()
    }

    private fun showMediana() {
        val medianaResult = values.ListaValores.sorted()
        val mid = medianaResult[0] + (medianaResult[medianaResult.lastIndex] - medianaResult[0]) / 2
        MedianaText.text = "Lista Ordenada:\n $medianaResult\nMediana: $mid"
    }

    private fun calcDesvio() {
        var resultDesvio = 0.0
        var desvioString = ""

        for (i in values.ListaValores) {
            resultDesvio = if (i > resultMedia) {
                i - resultMedia
            } else {
                resultMedia - i
            }
            desvioString += "$resultDesvio\n"
            desvioList.add(resultDesvio)
        }
        desvioText.text = "Lista Ordenada Desvio Normal: \n$desvioString"
    }

    private fun showVarianciaAmostral() {
        var itemPow: Double = 0.0
        var itemSum: Double = 0.0

        for (i in desvioList) {
            itemPow = i.pow(2.0)
            desvioPowList.add(itemPow)
        }

        itemSum = desvioPowList.sum()
        resultVarianciaAmostral = itemSum / desvioPowList.size
        varianciaAmostralText.text = "Variancia Amostral: $resultVarianciaAmostral"
    }

    private fun showDesvioPadrao() {
        resultDesvioPadrao = sqrt(resultVarianciaAmostral)
        desvioPadraoText.text = "Desvio Padrão: $resultDesvioPadrao"
    }

    private fun showCoeficienteVariacao() {
        var resultCoeficienteVariacao: Double = 0.0
        var coeficienteDiv = resultDesvioPadrao / resultMedia
        resultCoeficienteVariacao = coeficienteDiv * 100
        coeficienteVariacaoText.text = "Coeficiente de Variação: $resultCoeficienteVariacao%"
    }

    private fun closeDialog() {
        dialog.findViewById<ImageView>(R.id.closeButton)?.setOnClickListener {
            dialog.dismiss()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        rootView = inflater.inflate(modal_calc, container, false)
        return rootView
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
        return dialog
    }
}