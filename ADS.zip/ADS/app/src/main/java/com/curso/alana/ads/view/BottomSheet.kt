package com.curso.alana.ads.view

import android.app.Dialog
import android.content.res.Resources
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.curso.alana.ads.R
import com.curso.alana.ads.R.id.*
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.curso.alana.ads.databinding.ModalCalcBinding
import com.curso.alana.ads.model.Values
import kotlin.math.pow
import kotlin.math.sqrt


class BottomSheet(private val values: Values) : BottomSheetDialogFragment() {

    private lateinit var binding: ModalCalcBinding

    lateinit var dialog: BottomSheetDialog
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<View>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bottomSheetBehavior = BottomSheetBehavior.from(view.parent as View)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        val layout = dialog.findViewById<CoordinatorLayout>(bottom)
        layout?.minimumHeight = (Resources.getSystem().displayMetrics.heightPixels)

        setUpComponents()
    }

    private fun setUpComponents() {
        showMediaAritimetica()
        showMediana()
        showVarianciaAmostral()
        closeDialog()
    }

    private fun showMediaAritimetica() {
        binding.resultText.text = "Média Aritimética: ${calcMediaAritimetica()}"
    }

    private fun calcMediaAritimetica(): Double {
        return values.ListaValores.sumOf { it.toDouble() / values.ListaValores.size }
    }

    private fun showMediana() {
        val medianaOrderList = values.ListaValores.sorted()
        val mdValueString = showListOrderly(medianaOrderList) +
                "\n\nMediana: " +  if (isNumberPar()) {
                    "${calcParMediana(medianaOrderList)}"
                } else {
                    "${calcImparMediana(medianaOrderList)}"
                }
        binding.resultMediana.text = mdValueString
    }

    private fun showListOrderly(mdOrderList: List<Float>): String {
        var mdOrderString = ""

        for (item in mdOrderList) {
            mdOrderString += "\n$item"
        }
        return "Lista Ordenada: $mdOrderString"
    }

    private fun isNumberPar(): Boolean {
        return values.ListaValores.size % 2 == 0
    }

    private fun calcParMediana(mdOrderList: List<Float>): Float {
        val mdFirstPosition = (mdOrderList.size - 1) / 2
        val mdSecondPosition = mdFirstPosition + 1
        return calcMedia(mdOrderList[mdFirstPosition], mdOrderList[mdSecondPosition], 2F)
    }

    private fun calcImparMediana(mdOrderList: List<Float>): Float {
        val mdMiddlePosition = ((mdOrderList.size + 1) / 2) - 1
        return mdOrderList[mdMiddlePosition]
    }

    private fun calcMedia(firstValue: Float, secondValue: Float, listSize: Float): Float {
        return (firstValue + secondValue) / listSize
    }

    private fun showVarianciaAmostral() {
        binding.resultVarianciaAmostral.text = "${getString(R.string.variancia_amostral_title)}${calcVarianciaAmostral()}"
    }

    private fun calcVarianciaAmostral(): String {
        val mediaList = calcMedia(values.ListaValores.sorted().sum(), 0F, values.ListaValores.size.toFloat())
        val varianciaList = createVarianciaList(mediaList)
        val varianciaSquaredList = createSquaredVarianciaList(varianciaList)

        val varianciaListResult = varianciaSquaredList.sum() / (varianciaSquaredList.size - 1)
        showDesvioPadrao(varianciaListResult)

        return "$varianciaListResult"
    }

    private fun createVarianciaList(media: Float): List<Float> {
        val list = arrayListOf<Float>()

        for (item in values.ListaValores.sorted()) {
            val varianciaItemValue = item - media
            list.add(varianciaItemValue)
        }
        return list
    }

    private fun createSquaredVarianciaList(varianciaList: List<Float>): List<Float>  {
        val squaredList = arrayListOf<Float>()

        for (item in varianciaList) {
            squaredList.add(item.pow(2F))
        }

        return squaredList
    }

    private fun showDesvioPadrao(varianciaResult: Float) {
        binding.resultDesvioPadrao.text = "Desvio Padrão: ${calcDesvioPadrao(varianciaResult)}"
        showCoeficienteVariacao(calcDesvioPadrao(varianciaResult))
    }

    private fun calcDesvioPadrao(varianciaResult: Float): Float {
        return sqrt(varianciaResult)
    }

    private fun showCoeficienteVariacao(desvioPadrao: Float) {
        var resultCoeficienteVariacao: Float = 0F
        val coeficienteDiv = (desvioPadrao / calcMedia(values.ListaValores.sorted().sum(), 0F, values.ListaValores.size.toFloat())) * 100
        resultCoeficienteVariacao = coeficienteDiv  / 100
        binding.resultCoeficienteVariacao.text = "Coeficiente de Variação: $resultCoeficienteVariacao%"

        showConjuntoDados(resultCoeficienteVariacao)
    }

    private fun showConjuntoDados(coeficienteVariacao: Float) {
        binding.resultConjuntoDados.text = if (coeficienteVariacao <= 0.30) {
            getString(R.string.conjunto_homogeneo_text)
        } else {
            getString(R.string.conjunto_heterogeneo_text)
        }
    }

    private fun closeDialog() {
        dialog.findViewById<ImageView>(R.id.closeButton)?.setOnClickListener {
            dialog.dismiss()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = ModalCalcBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
        return dialog
    }
}